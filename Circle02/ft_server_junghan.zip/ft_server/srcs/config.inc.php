<?php

declare(strict_types=1);


$cfg['blowfish_secret'] = 'KRZzjzjwaQGiF44THfBP1Yy,4LvJz3;t';

$i = 0;

$i++;
/* Authentication type */
$cfg['Servers'][$i]['auth_type'] = 'cookie';
/* Server parameters */
$cfg['Servers'][$i]['host'] = 'localhost';
$cfg['Servers'][$i]['compress'] = false;
$cfg['Servers'][$i]['AllowNoPassword'] = false;



$cfg['UploadDir'] = '';
$cfg['SaveDir'] = '';
